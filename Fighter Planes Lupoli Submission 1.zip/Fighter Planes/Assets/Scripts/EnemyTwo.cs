using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyTwo : MonoBehaviour
{
    private float horizontalMovement = 2f; //Used to determine which direction the enemy is moving

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

        // Enemy moves down and to the left or right, bouncing off the side of the screen

        // If Enemy is on the side of the screen...
        if (transform.position.x > 10f || transform.position.x < -10f)
        {
            // Reverse Direction
            horizontalMovement *= -1;
        }

        transform.Translate(new Vector3(horizontalMovement, -1, 0) * Time.deltaTime * 3f);

        if (transform.position.y < -8.5f)
        {
            Destroy(this.gameObject);
        }
    }
}
