using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    public GameObject player;
    public GameObject enemy;
    public GameObject enemyTwo; // Second Enemy Type
    public GameObject coin; // Coin used to increment the score

    private int lives = 3; // Tracks the player's current lives as an integer
    public TextMeshProUGUI livesCounter; // Used to keep track of the player's current lives as text

    private int score = 0; // Tracks the player's current score as an integer
    public TextMeshProUGUI scoreText; // Used to keep track of the player's current score as text
    
    private Player playerScript;  // Reference to the Player script

    // Start is called before the first frame update
    void Start()
    {
        // Instantiating Player
        Instantiate(player, transform.position, Quaternion.identity);

        // Repeatedly spawning enemies and coins
        InvokeRepeating("CreateEnemy", 1f, 3f);
        InvokeRepeating("CreateEnemyTwo", 2f, 5f); // Spawns the second custom enemy type
        InvokeRepeating("CreateCoin", 5f, 7f);

        // Creating Score Text
        UpdateScoreText();
        // Creating Lives Text
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    // Updates the current amount of lives for the lives counter
    void UpdateLives()
    {
        if (livesCounter != null)
        {
            livesCounter.text = "Lives: " + lives;
            if (lives == 0)
            {
                GameOver();
            }
        }
        else
        {
            Debug.LogError("livesCounter not assigned!");
        }
    }

    // Increments lives by a set amount
    public void IncrementLives(int val)
    {
        lives += val;
        UpdateLives();
    }

    // Increments score by a set amount
    public void IncrementScore(int val)
    {
        score += val;
        UpdateScoreText();
    }

    // Updates the Score Text UI
    private void UpdateScoreText()
    {
        if (scoreText != null)
        {
            scoreText.text = "Score: " + score;
        }
        else
        {
            Debug.LogError("ScoreText not assigned!");
        }
    }

    // Used to create the first enemy type
    void CreateEnemy()
    {
        Instantiate(enemy, new Vector3(Random.Range(-9f, 9f), 9f, 0), Quaternion.identity);
    }

    // Used to spawn the second enemy type
    void CreateEnemyTwo()
    {
        Instantiate(enemyTwo, new Vector3(Random.Range(-9f, 9f), 9f, 0), Quaternion.identity);
    }

    // Used to create coins
    void CreateCoin()
    {
        Instantiate(coin, new Vector3(Random.Range(-9f, 9f), 9f, 0), Quaternion.identity);
    }

    // Freezes the game and outputs a message to simulate a gameover
    void GameOver()
    {
        Time.timeScale = 0f;
        Debug.Log("Game Over!");
    }
}
