using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyTwo : MonoBehaviour
{
    private float horizontalMovement = 2f; //Used to determine which direction the enemy is moving

    public int damage = 1; // Determines how much damage the enemy does
    public GameManager gameManager;

    // Start is called before the first frame update
    void Start()
    {
        // Dynamically accessing game manager
        // No matter what I did I could not get my code to recognize Game Manager, this was the only solution I could find
        gameManager = FindObjectOfType<GameManager>();
    }

    // Update is called once per frame
    void Update()
    {

        // Enemy moves down and to the left or right, bouncing off the side of the screen

        // If Enemy is on the side of the screen...
        if (transform.position.x > 10f || transform.position.x < -10f)
        {
            // Reverse Direction
            horizontalMovement *= -1;
        }

        transform.Translate(new Vector3(horizontalMovement, -1, 0) * Time.deltaTime * 3f);

        if (transform.position.y < -8.5f)
        {
            Destroy(this.gameObject);
        }
    }

    // Detects if the player comes into contact with an enemy
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            if (gameManager != null)
            {
                //Increment's player's score
                gameManager.IncrementLives(damage * -1);
            }
            else
            {
                Debug.LogError("GameManager not found!");
            }

            //Destroy's coin object to prevent picking up the same coin multiple times
            Destroy(this.gameObject);
        }
    }
}
