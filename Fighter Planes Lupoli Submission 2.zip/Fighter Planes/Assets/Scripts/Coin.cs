using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coin : MonoBehaviour
{
    public int scoreVal = 1; // Determines how many points to award a player when a coin is picked up
    public GameManager gameManager;

    // Start is called before the first frame update
    void Start()
    {
        // Dynamically accessing game manager
        // No matter what I did I could not get my code to recognize Game Manager, this was the only solution I could find
        gameManager = FindObjectOfType<GameManager>();
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(new Vector3(0, -1, 0) * Time.deltaTime * 3f);
        if (transform.position.y < -8.5f)
        {
            Destroy(this.gameObject);
        }
    }

    // Detects if the player comes into contact with a coin
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            if (gameManager != null)
            {
                //Increment's player's score
                gameManager.IncrementScore(scoreVal);
            }
            else
            {
                Debug.LogError("GameManager not found!");
            }

            //Destroy's coin object to prevent picking up the same coin multiple times
            Destroy(this.gameObject);
        }
    }
}
